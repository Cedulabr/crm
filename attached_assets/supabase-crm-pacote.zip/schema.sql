
-- Tabela de clientes
create table if not exists clients (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  phone text not null,
  email text,
  created_at timestamp default now()
);

-- Tabela de propostas
create table if not exists proposals (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references clients(id),
  value numeric,
  status text default 'pendente',
  created_at timestamp default now()
);
