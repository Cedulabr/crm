
import express from 'express';
import supabase from '../supabaseClient';

const router = express.Router();

router.post('/', async (req, res) => {
  const { name, phone, email } = req.body;

  const { data, error } = await supabase
    .from('clients')
    .insert([{ name, phone, email }]);

  if (error) return res.status(500).json({ error: error.message });

  return res.status(200).json({ data });
});

router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('clients').select('*');
  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
});

export default router;
