
import express from 'express';
import supabase from '../supabaseClient';

const router = express.Router();

router.post('/', async (req, res) => {
  const { client_id, value, status } = req.body;

  const { data, error } = await supabase
    .from('proposals')
    .insert([{ client_id, value, status }]);

  if (error) return res.status(500).json({ error: error.message });

  return res.status(200).json({ data });
});

router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('proposals').select('*');
  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
});

export default router;
